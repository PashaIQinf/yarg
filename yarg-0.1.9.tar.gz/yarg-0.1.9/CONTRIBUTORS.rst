Contributors
============

Developer
---------

- Kura <kura@kura.io>

Requests library
----------------

- Kenneth Reitz <me@kennethreitz.org>
